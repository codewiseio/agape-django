from django.apps import AppConfig


class PropertiesConfig(AppConfig):
    name = 'properties'
